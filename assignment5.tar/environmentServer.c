#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <pthread.h>
#include <semaphore.h>
#include <sys/socket.h>
#include <netinet/in.h>

#include "simulator.h"

//the environment variable
Environment    environment;
//forward reference
void *handleIncomingRequests(void *e);

//function to check for collisions
//calculates a move ahead because the server needs to predict where the client is going, now where it is now
int checkCollision(float *checkcollide){
	float newx;
	float newy;
	newx = environment.robots[(int)checkcollide[1]].x + (ROBOT_SPEED *cos(environment.robots[(int)checkcollide[1]].direction*PI/180));
	newy = environment.robots[(int)checkcollide[1]].y + (ROBOT_SPEED *sin(environment.robots[(int)checkcollide[1]].direction*PI/180));
	if(newx < ROBOT_RADIUS||newx > ENV_SIZE - ROBOT_RADIUS ||newy > ENV_SIZE - ROBOT_RADIUS|| newy < ROBOT_RADIUS){
			//send that it will collide with border
			return NOT_OK_BOUNDARY;
	
	
		}
	//goes through the entire array of robots and checks the distance between 2 points 	
	for(int i = 0; i < environment.numRobots; i++){
		if(i != checkcollide[1]){
			if(sqrt(pow(newx-environment.robots[i].x,2)+pow(newy-environment.robots[i].y,2)) <= 2 * ROBOT_RADIUS){
				//collision with robot is detected
				return NOT_OK_COLLIDE;
			}
		}
	}
	//everything is good
	return OK;	
}



// Handle client requests coming in through the server socket.  This code should run
// indefinitiely.  It should repeatedly grab an incoming messages and process them. 
// The requests that may be handled are STOP, REGISTER, CHECK_COLLISION and STATUS_UPDATE.   
// Upon receiving a STOP request, the server should get ready to shut down but must
// first wait until all robot clients have been informed of the shutdown.   Then it 
// should exit gracefully.  
void *handleIncomingRequests(void *e) {
	char   online = 1;
	environment.numRobots = 0;
	// ... ADD SOME VARIABLE HERE... //
	int                 serverSocket;
  	struct sockaddr_in  serverAddr, clientAddr;
  	int                 status, addrSize, bytesReceived;
	fd_set              readfds, writefds;
  	float                buffer[30];
  	float               response;
  	
	// Initialize the server
	
	// Create the server socket
	serverSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if (serverSocket < 0) {
		printf("*** SERVER ERROR: Could not open socket.\n");
		exit(-1);
	}
	
	// Setup the server address
	memset(&serverAddr, 0, sizeof(serverAddr)); // zeros the struct
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);
	serverAddr.sin_port = htons((unsigned short) SERVER_PORT);

	// Bind the server socket
	status = bind(serverSocket, (struct sockaddr *) &serverAddr, sizeof(serverAddr));
	if (status < 0) {
		printf("*** SERVER ERROR: Could not bind socket.\n");
		exit(-1);
	}
	
	
	
	
	
	
	
	
	

	// Wait for clients now
	while (online) {
	
		// ... WRITE YOUR CODE HERE ... //
	
		FD_ZERO(&readfds);
		FD_SET(serverSocket, &readfds);
		FD_SET(serverSocket, &writefds);
		status = select(FD_SETSIZE, &readfds, &writefds, NULL, NULL);
		if (status == 0) {
		// Timeout occurred, no client ready
		}
		else if (status < 0) {
			printf("*** SERVER ERROR: Could not select socket.\n");
			exit(-1);
		}
		else{
			//this is where the bulk of the server code will be
			//this is used to receive the buffer
			addrSize = sizeof(clientAddr);
			bytesReceived = recvfrom(serverSocket, buffer, sizeof(buffer),
                        0, (struct sockaddr *) &clientAddr, &addrSize);
                        
                        
      			if(buffer[0] == STOP){
      				//server is terminated break out of loop
      				break;
      			}
      			//registration	
      			else if(buffer[0] ==REGISTER){
      				if(environment.numRobots < MAX_ROBOTS){
      					//if conditions are ok send a ok statement
      					buffer[0] = OK;
      					sendto(serverSocket, buffer, sizeof(OK), 0,(struct sockaddr *) &clientAddr, sizeof(clientAddr));
      					//found used to determine if legit spawning point can be achieved
   					int found = 0;
   					//while not founnd
      					while(found != 1){
      						//generate random values
      						float randomx = (rand() % ((ENV_SIZE - ROBOT_RADIUS) - ROBOT_RADIUS + 1)) + ROBOT_RADIUS; 
      						float randomy = (rand() % ((ENV_SIZE - ROBOT_RADIUS) - ROBOT_RADIUS + 1)) + ROBOT_RADIUS; 
      						int randomdir = (rand() % (180 - -180 + 1)) + -180; 
      						for(int i = 0; i < environment.numRobots; i++){
      							//if the spawnpoint is inside of another robot
      							if(sqrt(pow(randomx-environment.robots[i].x,2)+pow(randomy-environment.robots[i].y,2)) <= 2 * ROBOT_RADIUS){
      								found =0;
      							}
      						}
      						//if spawnpoint is touching the edge
      						if(randomx <= ROBOT_RADIUS || randomx >= ENV_SIZE-ROBOT_RADIUS || randomy <= ROBOT_RADIUS || randomy >= ENV_SIZE){
      							found = 0;
      						}
      						else{
      							found = 1;
      							environment.robots[environment.numRobots].x =randomx;
				 			environment.robots[environment.numRobots].y = randomy;
				 			environment.robots[environment.numRobots].direction = randomdir;
      						}
      					
      					}
      					//set the values of the buffer to be sent to the client 
				 	buffer[0] = OK;
				 	buffer[1] = environment.numRobots;
				 	buffer[2] = environment.robots[environment.numRobots].x;
				 	buffer[3] = environment.robots[environment.numRobots].y;
				 	buffer[4] = (float)environment.robots[environment.numRobots].direction;
				 	sendto(serverSocket, buffer,sizeof(buffer), 0,(struct sockaddr *) &clientAddr, sizeof(clientAddr));
				 	//increase num robots
				 	environment.numRobots++;
      				}
      				else{
      					//if robot cannot spawn 
      					buffer[0] = NOT_OK;
      					sendto(serverSocket, buffer, sizeof(buffer), 0,(struct sockaddr *) &clientAddr, sizeof(clientAddr));
      				}
      			}
      			//collision report check. receive a report and then check collision and send the int result
      			else if(buffer[0] == CHECK_COLLISION){
      				buffer[0] = checkCollision(buffer);
      				sendto(serverSocket, buffer, sizeof(buffer), 0,(struct sockaddr *) &clientAddr, sizeof(clientAddr));
      				
      			}
      			///status update. if client wants a status update update the values
      			else if(buffer[0] == STATUS_UPDATE){
      				//updating the robots array
      				environment.robots[(int)buffer[1]].x = buffer[2];
      				environment.robots[(int)buffer[1]].y = buffer[3];
      				environment.robots[(int)buffer[1]].direction = (int)buffer[4];
      			}	
		}
	}
	// ... WRITE ANY CLEANUP CODE HERE ... //
	//run a loop to close all robots
	while(environment.numRobots != 0){
		addrSize = sizeof(clientAddr);
		bytesReceived = recvfrom(serverSocket, buffer, sizeof(buffer),
		0, (struct sockaddr *) &clientAddr, &addrSize);
		//this means they want a collision request. send them back a shutdown command
		if(buffer[0] == CHECK_COLLISION){
			buffer[0] = LOST_CONTACT;
			sendto(serverSocket, buffer, sizeof(float), 0,(struct sockaddr *) &clientAddr, 				sizeof(clientAddr));
			environment.numRobots--;
		}
	}
	//closing sockets and such
	close(serverSocket);
	environment.shutDown = 1;
}




int main() {
	//create 2 threads
	pthread_t t1,t2;


	// So far, the environment is NOT shut down
	environment.shutDown = 0;
  
	// Set up the random seed
	srand(time(NULL));

	// Spawn an infinite loop to handle incoming requests and update the display
	
	pthread_create(&t1, NULL, handleIncomingRequests, &environment);
	pthread_create(&t2, NULL, redraw, &environment);
	//make a infinite loop. not sure if this is required maybe remove
	
	// Wait for the update and draw threads to complete
	pthread_join(t1,NULL);
	pthread_join(t2,NULL);
	return 0;
}

