Adrian Cheung 101152541

source files submitted:
	display.c
	makefile
	simulator.h
	stop.c
	environmentServer.c
	robotClient.c
	readme.txt

Instructions on how to run the program
	open up cmd
	make sure you are in the right directory
	type in make
		this will make the program files
	type in the terminal
		./environmentServer &
		this will run it in the background
	type in the terminal
		./robotClient &
		this will run your robot clients
enjoy watching some roombas dance!
