#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <math.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "simulator.h"




// This is the main function that simulates the "life" of the robot
// The code will exit whenever the robot fails to communicate with the server
int main() {
	// ... ADD SOME VARIABLE HERE ... //
	int clientSocket, addrSize, bytesReceived;
	struct sockaddr_in  clientAddr;
	float buffer[80];
	
	// Set up the random seed
	srand(time(NULL));

	// Register with the server
	
	// Create socket
	clientSocket = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if (clientSocket < 0) {
		printf("*** CLIENT ERROR: Could open socket.\n");
		exit(-1);
	}
	
	// Setup address 
	memset(&clientAddr, 0, sizeof(clientAddr));
	clientAddr.sin_family = AF_INET;
	clientAddr.sin_addr.s_addr = inet_addr(SERVER_IP);
	clientAddr.sin_port = htons((unsigned short) SERVER_PORT);

	
	// Send register command to server.  Get back response data
	// and store it.   If denied registration, then quit.
	
	buffer[0] = REGISTER;
	sendto(clientSocket, buffer, sizeof(buffer), 0,(struct sockaddr *) &clientAddr, sizeof(clientAddr));
	float storage[2];
	addrSize = sizeof(clientAddr);
	bytesReceived = recvfrom(clientSocket, buffer,sizeof(buffer), 0,(struct sockaddr *) &clientAddr, &addrSize);
	//DONT FORGET TO STORE THE DATA
	//if value is not ok. exit the program nothing can be done
	if(buffer[0] == NOT_OK){
		exit(-1);
	}
	//you will then receive your unique id, x y and direction
	addrSize = sizeof(clientAddr);
	bytesReceived = recvfrom(clientSocket, buffer,sizeof(buffer) * 4, 0,(struct sockaddr *) &clientAddr, &addrSize);
	float currentid = buffer[1];
	float currentx = buffer[2];
	float currenty = buffer[3];
	int currentdir = (int)buffer[4];
	
	//DONT FORGET TO IMPLEMENT SOME SORT OF STATE TO DETERMINE IF LAST MOVE WAS SUCCESS
	//direction flag will be used to determine the direction of where the last turn was either left or right
	int directionflag;
	//success flag will be used to determine whether or not to go to the last turn that it was designated to avoid going left and right randomly consecutively
	int successflag;

	// Go into an infinite loop exhibiting the robot behavior
	while (1) {
	// Check if can move forward
		buffer[0] = CHECK_COLLISION; //status code 
		buffer[1] = currentid;
		buffer[2] = currentx;
		buffer[3] = currenty;
		buffer[4] = (float)currentdir;
		//send a collision request with current values
	 	sendto(clientSocket, buffer, sizeof(buffer), 0,(struct sockaddr *) &clientAddr, sizeof(clientAddr));
	 	  
	// Get response from server.
		addrSize = sizeof(clientAddr);
		recvfrom(clientSocket, buffer, sizeof(buffer), 0,(struct sockaddr *) &clientAddr, &addrSize);
		
	// If ok, move forward
		if(buffer[0] == 5){
			successflag = 0;
			//update the fields
			buffer[2] = (currentx + ROBOT_SPEED * cos(currentdir * PI /  180));
			buffer[3] = (currenty + ROBOT_SPEED * sin(currentdir * PI / 180));	
			currentx = buffer[2];
			currenty = buffer[3];
			currentdir = (int)buffer[4];
		}
		if(buffer[0] == LOST_CONTACT){
			close(clientSocket);  // Don't forget to close the socket !
			break;
		}
		
	// Otherwise, we could not move forward, so make a turn.
	// If we were turning from the last time we collided, keep
	// turning in the same direction, otherwise choose a random 
	// direction to start turning.
		if(buffer[0] == NOT_OK_BOUNDARY){
			if(currentdir < -180){
				currentdir+=360;	
			}
			if(currentdir >180){
				currentdir-=360;	
			}
			// 0 if prior time was a success aka first time
			if(successflag == 0){
				int random = (int)(rand()/(double)RAND_MAX*2);
				if(random == 1){
					currentdir += ROBOT_TURN_ANGLE;
					//direction flag 0 == left
					directionflag = 1;
					successflag = 1;
				}
				else{
					currentdir -= ROBOT_TURN_ANGLE;
					directionflag = 0;
					successflag = 1;
				}
			}
			else{
				if(directionflag == 0){
					currentdir += ROBOT_TURN_ANGLE;
				}
				else{
					currentdir -= ROBOT_TURN_ANGLE;
				}
			}
			buffer[4] = (float)currentdir;
		}
		if(buffer[0] == NOT_OK_COLLIDE){
			//this resets the robot if it is going past the designated angles aka you cannot have -800 degrees for example
			if(currentdir < -180){
				currentdir+=360;	
			}
			if(currentdir >180){
				currentdir-=360;	
			}
			// 0 if prior time was a success aka first time
			if(successflag == 0){
				int random = (int)(rand()/(double)RAND_MAX*2);
				if(random == 1){
					currentdir += ROBOT_TURN_ANGLE;
					//direction flag 0 == left
					directionflag = 1;
					successflag = 1;
				}
				else{
					currentdir -= ROBOT_TURN_ANGLE;
					directionflag = 0;
					successflag = 1;
				}
			}
			else{
				if(directionflag == 0){
					currentdir += ROBOT_TURN_ANGLE;
				}
				else{
					currentdir -= ROBOT_TURN_ANGLE;
				}
			}
			buffer[4] = (float)currentdir;
		}

	// Send update to server
	//creating the status update variables
		buffer[0] = STATUS_UPDATE;
		buffer[1] = currentid;
		buffer[2] = currentx;
		buffer[3] = currenty;
		buffer[4] = (float)currentdir;
	 	sendto(clientSocket, buffer, sizeof(buffer), 0,(struct sockaddr *) &clientAddr, sizeof(clientAddr));

	// Uncomment line below to slow things down a bit 
	usleep(1000);
	}
	exit(0);
}


